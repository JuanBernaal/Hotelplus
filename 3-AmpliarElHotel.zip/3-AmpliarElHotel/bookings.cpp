//
// Created by oscar on 15/08/2023.
//

#include "bookings.h"
#include <iostream>

Bookings::Bookings(){
}

Bookings::Bookings(Guest g, Room* r, int numbOfNights){
    this->bookingGuestData = g;
    this->roomInfo = r;
    this->nightsNumb = numbOfNights;
}

int Bookings::getNumberOfNights(){
    return this->nightsNumb;
}

int Bookings::totalPayment(int nightsNumber, Room* roomNumber){
    return nightsNumber * roomNumber->getCost();
}

void Bookings::info(){
    cout << "You have booked" << endl;
}