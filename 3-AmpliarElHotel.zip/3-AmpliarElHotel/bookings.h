//
// Created by oscar on 15/08/2023.
//

#ifndef INC_3_AMPLIARELHOTEL_BOOKINGS_H
#define INC_3_AMPLIARELHOTEL_BOOKINGS_H
#include <string>
#include "guest.h"
#include "room.h"

using namespace std;

class Bookings {
private:
    Guest bookingGuestData;
    Room* roomInfo;
    string checkInDate;
    string checkOutDate;
    int nightsNumb;
public:
    Bookings();

    Bookings(Guest g, Room* r, int numbOfNights);

    int getNumberOfNights();

    int totalPayment(int nightsNumber, Room* roomNumber);
    
    void info();
};


#endif //INC_3_AMPLIARELHOTEL_BOOKINGS_H