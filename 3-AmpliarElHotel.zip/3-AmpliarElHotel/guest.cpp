/*
 * Grupo: Oscar Vargas - Juan Diego Collazos
 * Fecha: 5/08/2023
 * guest.cpp
 */

#include "guest.h"

Guest::Guest(const string& name, const string& phoneNumber ){
    random_device rd;
    mt19937 mt(rd());
    uniform_int_distribution<int> dist(500, 1000);
    this->name = name;
    this->phoneNumber = phoneNumber;
    this->cash = dist(mt);
    this->email = "noEmail";
    this->payingMethod = "cash";
}

Guest::Guest(const string& name, const string& phoneNumber, const string& email, const string& payingMethod ){
    random_device rd;
    mt19937 mt(rd());
    uniform_int_distribution<int> dist(500, 1000);
    this->name = name;
    this->phoneNumber = phoneNumber;
    this->cash = dist(mt);
    this->payingMethod = payingMethod;
    this->email = email;
}

Guest::Guest(const string& name, const string& phoneNumber, const string& email ){
    random_device rd;
    mt19937 mt(rd());
    uniform_int_distribution<int> dist(500, 1000);
    this->name = name;
    this->phoneNumber = phoneNumber;
    this->cash = dist(mt);
    this->payingMethod = "cash";
    this->email = email;
}

Guest::Guest(){
    this->name = "Null";
    this->phoneNumber = "-1" ;
    this->cash = -1;
    this->payingMethod = "Cash";
    this->email = "noEmail";
}

string Guest::getName(){
    return this->name;
}

string Guest::getEmail(){
    return this->email;
}

string Guest::getPhoneNumber(){
    return this->phoneNumber;
}

string Guest::getPayingMethod(){
    return this->payingMethod;
}

int Guest::getCash(){
    return this->cash;
}

void Guest::info(){
    cout << "-----------------------------------"<< endl;
    cout << "- Guest:" << endl;
    cout << "Name: " << this->getName() << endl;
    cout << "Cel: " << this->getPhoneNumber() << endl;
}

void Guest::pay( int valor ){
    this->cash -= valor;
}
