/*
 * Grupo: Oscar Vargas - Juan Diego Collazos
 * Fecha: 5/08/2023
 * Clase Guest
 */

#ifndef GUEST_H
#define GUEST_H

#include <string>
#include <iostream>
#include <random>

using namespace std;

class Guest{
public:
    string name;
    string phoneNumber;
    int cash;
    string payingMethod;
    string email;
public:
    Guest( const string& name, const string& phoneNumber, const string& email );
    Guest( const string& name, const string& phoneNumber, const string& email, const string&payingMethod );
    Guest( const string& name, const string& phoneNumber );
    Guest();

    /*
     * setters y getters
     */
    string getName();
    string getPhoneNumber();
    int getCash();
    string getEmail();
    string getPayingMethod();
    /*
     * metodos
     */
    void pay(int value);
    void info();
};

#endif
