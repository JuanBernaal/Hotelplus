/*
 * Grupo: Oscar Vargas - Juan David Bernal - Juan Diego Valencia - Marco Riascos - Rui Yu Lei Wu
 * Fecha: 13/08/2023
 * main test
 */
#include <iostream>
#include "hotel.h"
#include "guest.h"
#include "room.h"
#include <string>

void test1();

int main(){
    test1();
}

void test1() {
    Hotel houston("Houston", "Cr 10 N 11-202", "456-123-741");
    Guest jorge("Jorge", "312-741-8523");
    Guest luis("Luis", "312-526-8523");
    Guest maria("Maria", "312-526-1234");
    Guest juan("Juan", "312-741-9856");
    Guest oscar("oscar", "325-895-412");

    houston.bookRoom(1, jorge, 3);
    houston.bookRoom(4, maria, 2);
    houston.bookRoom(7, luis, 1);
    houston.bookInfo();
    houston.freeRoom(1);
    houston.freeRoom(4);
    houston.receiptInfo();
    houston.bookRoom(1, oscar, 4);
    houston.bookInfo();
}

