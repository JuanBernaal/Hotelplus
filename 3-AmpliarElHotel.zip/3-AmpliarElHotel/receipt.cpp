//
// Created by oscar on 15/08/2023.
//

#include "receipt.h"
#include <iostream>

Receipt::Receipt(){
}

Receipt::Receipt(Bookings* booking, int cost, string paymentMethod){
    this->bookInfo = booking;
    this->pay = cost;
    this->paymentMethod = paymentMethod;
}

string Receipt::getPaymentMethod(){
    return this->paymentMethod;
}

int Receipt::getPayAmmount(){
    return this->pay;
}

void Receipt::info(){
    //cout << "A Marco le gustan las de 30 :)";
    cout << "Your payment has been succesful" << endl;
}