//
// Created by oscar on 15/08/2023.
//

#ifndef INC_3_AMPLIARELHOTEL_RECEIPT_H
#define INC_3_AMPLIARELHOTEL_RECEIPT_H
#include <string>
#include "bookings.h"

using namespace std;

class Receipt {
private:
    string paymentMethod;
    int pay;
    Bookings* bookInfo;
public:
    Receipt();
    Receipt(Bookings* booking, int cost, string paymentMethod);
    string getPaymentMethod();
    int getPayAmmount();
    void info();
};


#endif //INC_3_AMPLIARELHOTEL_RECEIPT_H
